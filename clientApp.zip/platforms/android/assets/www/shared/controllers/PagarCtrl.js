"use strict";

var app = angular.module('ng-laravel');
app.controller('PagarCtrl', function ($scope, $auth, $state, $rootScope, $ionicLoading,$cordovaNetwork,ionicToast,$ionicPlatform) {
    
 

    


});
